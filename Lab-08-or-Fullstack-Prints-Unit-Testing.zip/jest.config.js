module.exports = {
  // Uncomment this when you begin testing w/in-memory database
preset: '@shelf/jest-mongodb',
  testEnvironment: 'node',
};
