// tests/orders.test.js

const { create, get, list, edit } = require('../orders');

const orderData = require('../data/order1.json');

const { create: createProduct } = require('../products');

const productData = require('../data/product1.json');

describe('Orders Module', () => {

  let createdProduct;

  let createdOrder;

  // Populate the database with dummy data

  beforeAll(async () => {

    // Create a product and capture it

    createdProduct = await createProduct(productData);

    // Use the product id and pass it to the order data product id array;

    orderData.products = [createdProduct._id];

  });

  describe('list', () => {

    it('should list orders', async () => {

      const orders = await list();

      expect(orders.length).toBeGreaterThan(0);

    });

  });

  describe('create', () => {
    it('should create an order', async () => {

      createOrder = await create(orderData);

      expect(createOrder).toBeDefined();

      expect(createOrder.buyerEmail).toBe(orderData.buyerEmail);

    });

  });

  describe('get', () => {
    it('should get an order', async () => {

      const order = await get(createdOrder._id);

      expect(order).toBeDefined();

      expect(order.buyerEmail).toBe(orderData.buyerEmail);

    });

  });

  describe('edit', () => {
    it('should edit an order', async () => {
      const editedOrder = await edit(createdOrder._id, change);

      expect(editedOrder).toBeDefined();

      expect(editedOrder.status).toBe(orderData.status);

    })
  })

});
